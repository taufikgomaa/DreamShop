<template>
   <footer class="py-5 bg-black mt-5">
            <div class="container px-5"><p class="m-0 text-center text-white small">Copyright &copy; DreamShop 2022</p></div>
        </footer>
</template>

